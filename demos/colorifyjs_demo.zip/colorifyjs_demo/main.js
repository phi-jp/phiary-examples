/*
 * runstant
 */

window.onload = function() {
  colorify({
    container: 'colorify-gradient-color',
    accuracy: 10,
    gradient: true,
    gradientDirection: 'to bottom right'
  });
};
